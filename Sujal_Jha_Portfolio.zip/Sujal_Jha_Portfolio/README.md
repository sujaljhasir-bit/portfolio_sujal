# Sujal Jha: Portfolio

A one-page portfolio in black and neon pink. It is a single file (`index.html`) with no build step and no dependencies. Open it in any browser. It only needs internet to load the two Google Fonts (Archivo and Hanken Grotesk); without internet it falls back to Helvetica or Arial.

## What is in it

- **Hero:** name, role, GitHub and LinkedIn icons, and an animated ribbon of neon lines drawn on a canvas.
- **Expertise:** skills grouped under centered headings (Backend, Frontend, Data, Stacks, Shipping, Foundations), each listed as points.
- **History:** a centered timeline (Dehix, Velopp, B.Tech, training, debate).
- **Projects:** Live Watch and Movie Ticket Booking API, each with a centered heading and bullet points.
- **Contact:** email with a copy button, plus LinkedIn, GitHub and the Live Watch demo.

## Skills needed to build this portfolio

1. HTML5: semantic structure (header, main, section, article, footer) and accessible labels.
2. CSS3: custom properties (design tokens), flexbox, grid, `clamp()` for fluid type, media queries for phone and tablet layouts, sticky positioning, transitions and hover glow, `color-mix()`.
3. Responsive design: a mobile-first mindset, safe-area padding, no horizontal scrolling.
4. Typography: pairing a display face (Archivo, expanded weights) with a body face (Hanken Grotesk), and loading fonts from Google Fonts.
5. JavaScript (vanilla): DOM selection, event listeners, the Clipboard API with a fallback, IntersectionObserver, `requestAnimationFrame`.
6. Canvas 2D: drawing and animating many curves, handling device pixel ratio and resize, pausing when off screen.
7. Color and visual design: a restrained palette (black, one pink, muted grey), contrast checking, glow effects used in one place.
8. Accessibility: keyboard focus styles, `prefers-reduced-motion` support, `aria-label`s on icon links, contrast.
9. SVG: inline icons for GitHub and LinkedIn.
10. Content writing: short, specific copy taken from the resume, written in plain language.
11. Deployment: putting a static page online (GitHub Pages, Netlify, Vercel or Cloudflare Pages).
12. Git and GitHub: version control and publishing the project.

## Put it online (free)

- **GitHub Pages:** create a repository, upload `index.html`, then Settings, Pages, choose the main branch.
- **Netlify Drop:** drag the folder containing `index.html` onto app.netlify.com/drop.

## Edit it

- **Colors:** the `:root` block at the top of the `<style>` tag. Change `--accent` for the pink, `--bg` for the black, and `--wave-a` / `--wave-b` (R G B values) for the hero lines.
- **Text:** everything is plain HTML inside `<main>`. Each section is marked by its `id` (expertise, history, projects, contact).
- **Photo:** replace the `<div class="avatar">SJ</div>` in the hero with `<img class="avatar" src="your-photo.jpg" alt="Sujal Jha">` and add `object-fit: cover;` to the `.avatar` CSS rule.
- **Email and links:** search for `sujaljhasir@gmail.com`, `github.com/sujaljhasir-bit` and `linkedin.com/in/sujal-jha-6b1501285`.
- **Booking project link:** the "See my GitHub" link points to your profile. Replace it with the repository URL once you have one.
